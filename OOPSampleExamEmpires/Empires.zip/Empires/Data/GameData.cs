﻿using Empires.Interfaces;
using Empires.Models.Buildings;
using Empires.Models.Recorces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empires.Data
{
    public class GameData : IData
    {

    }
}
