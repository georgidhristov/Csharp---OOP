﻿using Exam_Blobs.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam_Blobs.Core
{
    public class Attacks : IAttacks
    {
        public IBlob PutridFart(IBlob attacker, IBlob defender)
        {
            defender.Health = defender.Health - attacker.Damage;

            return defender;
        }

        public IBlob[] Blobplode(IBlob attacker, IBlob defender)
        {
            int remainedHealth = attacker.Health / 2;
            attacker.Health = remainedHealth;

            defender.Health = defender.Health - (attacker.Damage * 2);

            IBlob[] blobArray = { attacker, defender };

            return blobArray;
        }
    }
}
