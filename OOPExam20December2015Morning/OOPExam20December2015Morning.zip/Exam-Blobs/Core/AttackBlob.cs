﻿using Exam_Blobs.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam_Blobs.Core
{
    public class AttackBlob : IAttackBlob
    {
        Attacks attaks = new Attacks();
        Behaviors behaviors = new Behaviors();

        public List<IBlob> Attack(List<IBlob> blobs, string attacker, string defender)
        {
            int attackerIndex = 0;
            int defenderIndex = 0;
            for (int i = 0; i < blobs.Count; i++)
            {
                if (blobs[i].Name == attacker)
                {
                    attackerIndex = i;
                }
                if (blobs[i].Name == defender)
                {
                    defenderIndex = i;
                }
            }

            int attackerHalfHealth = blobs[attackerIndex].Health / 2;
            int defenderHalfHealth = blobs[defenderIndex].Health / 2;

            if (blobs[attackerIndex].Attack == "PutridFart")
            {
                blobs[defenderIndex] = attaks.PutridFart(blobs[attackerIndex], blobs[defenderIndex]);
            }
            else if (blobs[attackerIndex].Attack == "Blobplode")
            {
                IBlob[] blobArray = new IBlob[2];
                blobArray = attaks.Blobplode(blobs[attackerIndex], blobs[defenderIndex]);
                blobs[attackerIndex] = blobArray[0];
                blobs[defenderIndex] = blobArray[1];
            }
            if (blobs[attackerIndex].Health <= attackerHalfHealth)
            {
                if (blobs[attackerIndex].Behavior == "Aggressive")
                {
                    blobs[attackerIndex] = behaviors.AggressiveBehavior(blobs[attackerIndex]);
                }
                else if (blobs[attackerIndex].Behavior == "Inflated")
                {
                    blobs[attackerIndex] = behaviors.InflatedBehavior(blobs[attackerIndex]);
                }
            }
            if (blobs[defenderIndex].Health <= defenderHalfHealth)
            {
                if (blobs[defenderIndex].Behavior == "Aggressive")
                {
                    blobs[defenderIndex] = behaviors.AggressiveBehavior(blobs[defenderIndex]);
                }
                else if (blobs[defenderIndex].Behavior == "Inflated")
                {
                    blobs[defenderIndex] = behaviors.InflatedBehavior(blobs[defenderIndex]);
                }
            }
            return blobs;
        }
    }
}
