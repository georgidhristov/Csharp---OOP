﻿using ExamBlobs.Interfaces;
using ExamBlobs.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamBlobs.GameData
{
    public class Data
    {
        private List<string> blobStatus = new List<string>();

        public List<string> BlobStatus
        {
            get { return blobStatus; }
            set { blobStatus = value; }
        }

        public void BlobStatusAdd(string blob)
        {
            BlobStatus.Add(blob);
        }
        public void BlobStatusRemove(string blob)
        {
            BlobStatus.Remove(blob);
        }
    }
}
