﻿using ExamBlobs.GameData;
using ExamBlobs.Interfaces;
using ExamBlobs.IO;
using ExamBlobs.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamBlobs.Core
{
    public class Engine : IRunnable
    {
        public void Run()
        {
            ConsoleRead consoleRead = new ConsoleRead();
            ConsoleWrite consoleWrite = new ConsoleWrite();
            CreateBlobs createBlob = new CreateBlobs();
            Data data = new Data();
            AttackBlobs attackBlob = new AttackBlobs();

            string input = "";

            while (input != "drop")
            {
                input = consoleRead.Read();

                string[] commant = input.Split();

                if (commant[0] == "create")
                {
                    string name = commant[1];
                    int health = Int32.Parse(commant[2]);
                    int damage = Int32.Parse(commant[3]);
                    string behavior = commant[4];
                    string attack = commant[5];

                    data.BlobStatusAdd(input);
                }
                else if (commant[0] == "attack")
                {
                    string attacker = "";
                    string attacked = "";
                    for (int i = 0; i < data.BlobStatus.Count(); i++)
                    {
                        if (data.BlobStatus[i].Contains(commant[1]))
                        {
                            attacker = data.BlobStatus[i];
                        }
                        if (data.BlobStatus[i].Contains(commant[2]))
                        {
                            attacked = data.BlobStatus[i];
                        }
                    }
                    string[] arr = attackBlob.Attack(attacker, attacked);

                    for (int i = 0; i < data.BlobStatus.Count(); i++)
                    {
                        if (data.BlobStatus[i].Contains(commant[1]))
                        {
                            data.BlobStatus[i] = arr[0];
                            
                        }
                        if (data.BlobStatus[i].Contains(commant[2]))
                        {
                            data.BlobStatus[i] = arr[1]; 
                        }
                    }
                }
                else if (commant[0] == "status")
                {
                    consoleWrite.WriteList(data.BlobStatus);
                }
                else if (commant[0] == "pass")
                {

                }
                else if (commant[0] == "drop")
                {
                    Environment.Exit(0);
                }
            }
        }
    }
}
