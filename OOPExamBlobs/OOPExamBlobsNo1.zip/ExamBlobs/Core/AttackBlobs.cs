﻿using ExamBlobs.GameData;
using ExamBlobs.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamBlobs.Models
{
    public class AttackBlobs : IAttacks
    {
        public string[] Attack(string attacker, string attacked)
        {
            string[] attackerStatus = attacker.Split();
            string attackerName = attackerStatus[1];
            int attackerHealth = Int32.Parse(attackerStatus[2]);
            int attackerDamage = Int32.Parse(attackerStatus[3]);
            string attackerBehaviorSpell = attackerStatus[4];
            string attackerAttackSpell = attackerStatus[5];
            int attackerActivation = attackerHealth / 2; 

            string[] attackedStatus = attacked.Split();
            string attackedName = attackedStatus[1];
            int attackedHealth = Int32.Parse(attackedStatus[2]);
            int attackedDamage = Int32.Parse(attackedStatus[3]);
            string attackedBehaviorSpell = attackedStatus[4];
            string attackedAttackSpell = attackedStatus[5];
            int attackedActivation = attackedHealth / 2;

            if (attackerAttackSpell == "PutridFart")
            {
                attackedHealth = attackedHealth - attackerDamage;
            }
            else if (attackerAttackSpell == "Blobplode")
            {
                int healtLeft = attackerHealth / 2;
                attackerHealth = healtLeft;

                attackedHealth = attackedHealth - (attackerDamage * 2);
            }
            while (attackedHealth < 0)
            {
                attackedHealth++;
            }
            if (attackerHealth <= attackerActivation)
            {
                if (attackerBehaviorSpell == "Aggressive")
                {
                    attackerDamage = attackerDamage * 2;
                }
                else if (attackerBehaviorSpell == "Inflated")
                {
                    attackerHealth = attackerHealth + 50;
                }     
            }
            if (attackedHealth <= attackedActivation)
            {
                if (attackedBehaviorSpell == "Aggressive")
                {
                    attackedDamage = attackedDamage * 2;
                }
                else if (attackedBehaviorSpell == "Inflated")
                {
                    attackedHealth = attackedHealth + 50;
                }
            }

            attacker = string.Format("{0} {1} {2} {3} {4} {5}",
                attackerStatus[0], attackerName, attackerHealth,
                attackerDamage, attackerBehaviorSpell, attackerAttackSpell);

            attacked = string.Format("{0} {1} {2} {3} {4} {5}",
               attackedStatus[0], attackedName, attackedHealth,
                attackedDamage, attackedBehaviorSpell, attackedAttackSpell);

            string[] result = new string[2] { attacker, attacked};

            return result;
        }
    }
}
